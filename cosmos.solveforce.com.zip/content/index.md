# Welcome to COSMOS
The SolveForce Universal Knowledge Infrastructure.