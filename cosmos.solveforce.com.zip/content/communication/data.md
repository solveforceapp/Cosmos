# Data
The payload of cosmic transmission.