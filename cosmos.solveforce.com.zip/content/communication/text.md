# Text
Encodable structure of symbols and grammar.