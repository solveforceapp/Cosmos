# Energy Grid
Power and language as one grid of interaction.