# Cosmos Definition
The universal recursive system of SolveForce.