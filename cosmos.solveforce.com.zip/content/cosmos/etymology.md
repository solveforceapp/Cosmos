# Etymology of Cosmos
From Greek kosmos: order, adornment, universe.