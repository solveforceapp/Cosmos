# Communication Laws
Rules of signal, transmission, resonance.