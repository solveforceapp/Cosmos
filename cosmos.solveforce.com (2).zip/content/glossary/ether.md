# Ether
Medium of transmission. Carrier of intent.