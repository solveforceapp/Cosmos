# Logos
Word as command and creative agent.