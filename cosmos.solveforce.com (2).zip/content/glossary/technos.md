# Technos
Skill, method, engineered system.