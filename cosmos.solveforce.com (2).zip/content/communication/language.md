# Language
Primary medium of Cosmos. All begins with the Word.