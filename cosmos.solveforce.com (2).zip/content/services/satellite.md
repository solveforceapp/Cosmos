# Satellite
Sky-layer communication nodes in the SolveForce Cosmos.