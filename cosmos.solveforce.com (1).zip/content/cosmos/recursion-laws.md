# Recursion Laws
Self-similar truths across disciplines.