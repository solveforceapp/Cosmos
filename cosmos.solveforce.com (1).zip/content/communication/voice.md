# Voice
Auditory signals in analog and digital universes.