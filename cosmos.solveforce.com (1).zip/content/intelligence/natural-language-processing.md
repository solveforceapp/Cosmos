# NLP
Transforming language into network signals.