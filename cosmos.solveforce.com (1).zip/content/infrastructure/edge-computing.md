# Edge Computing
Computation at the edge of awareness.